package com.firebase.empleadocrud;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.NetworkError;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.firebase.empleadocrud.modelo.TaskVO;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class GeneralActivity extends AppCompatActivity implements Response.Listener<JSONObject>, Response.ErrorListener {
    private ListView listView;
    private int idEmp;
    RequestQueue requestQueue;
    public static final String IP_SERVER = MainActivity.IP_SERVER;
    JsonObjectRequest jsonObjectRequest;
    ArrayList<String> listaDatos;
    ArrayList<TaskVO> listaregistro;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_general);
        listView = findViewById(R.id.listaId);
        requestQueue = Volley.newRequestQueue(getApplicationContext());
        traerDatos();
        consultaRegistrosToken();
    }


    public void traerDatos(){
        Bundle bundle =getIntent().getExtras();
        this.idEmp= bundle.getInt("id");
        Toast.makeText(this, ""+idEmp, Toast.LENGTH_SHORT).show();
    }

    private void consultaRegistrosToken() {
        String url;
        url = IP_SERVER+"/php_empleados/listadoTasks.php?fk_usuario="+idEmp;
        jsonObjectRequest= new JsonObjectRequest(Request.Method.GET,url,null,this,this );
        requestQueue.add(jsonObjectRequest);

    }

    @Override
    public void onErrorResponse(VolleyError error) {
        if (error instanceof TimeoutError) {
            Toast.makeText(getApplicationContext(), "error_network_timeout", Toast.LENGTH_SHORT).show();
        } else if (error instanceof ServerError) {
            Toast.makeText(getApplicationContext(), "error_server", Toast.LENGTH_SHORT).show();
        } else if (error instanceof NetworkError) {
            Toast.makeText(getApplicationContext(), "network error", Toast.LENGTH_SHORT).show();
        } else if (error instanceof ParseError) {
            Toast.makeText(getApplicationContext(), "parse error", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(getApplicationContext(), "algun otro error", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onResponse(JSONObject response) {
        TaskVO taskVO = null;

        JSONArray jsonArray = response.optJSONArray("tbl_task");
        listaregistro = new ArrayList<>();
        try{
            for (int i = 0; i<jsonArray.length(); i ++){
                taskVO = new TaskVO();
                JSONObject jsonObject = null;
                jsonObject = jsonArray.getJSONObject(i);
                taskVO.setId_tbl_task(jsonObject.getInt("id_tbl_task"));
                taskVO.setTitulo(jsonObject.optString("titulo"));
                taskVO.setComentario(jsonObject.optString("comentario"));
                taskVO.setHora(jsonObject.optString("hora"));
                taskVO.setFecha(jsonObject.optString("fecha"));
                taskVO.setFk_empleado(jsonObject.optInt("fk_empleado"));
                listaregistro.add(taskVO);

            }

            listaDatos = new ArrayList<>();
            for (int i = 0; i<listaregistro.size(); i++){
                listaDatos.add(listaregistro.get(i).getTitulo());
            }

            ArrayAdapter adapter = new ArrayAdapter(getApplicationContext(), android.R.layout.simple_list_item_1, listaDatos);
            listView.setAdapter(adapter);
            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    //  Toast.makeText(MainActivity.this, "A pulsado "+datos.get(position), Toast.LENGTH_SHORT).show();

                    Intent intent2 = new Intent(getApplicationContext(), DeleteModifActivity.class);
                    intent2.putExtra("id_tbl_task", listaregistro.get(position).getId_tbl_task());
                    intent2.putExtra("titulo", listaregistro.get(position).getTitulo());
                    intent2.putExtra("comentario", listaregistro.get(position).getComentario());
                    intent2.putExtra("hora", listaregistro.get(position).getHora());
                    intent2.putExtra("fecha", listaregistro.get(position).getFecha());
                    intent2.putExtra("id",idEmp);

                    startActivity(intent2);
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void onClick(View view) {
        Intent intent = new Intent(getApplicationContext(),InsertarActivity.class);
        intent.putExtra("id", idEmp);
        startActivity(intent);
        finish();
    }
}


