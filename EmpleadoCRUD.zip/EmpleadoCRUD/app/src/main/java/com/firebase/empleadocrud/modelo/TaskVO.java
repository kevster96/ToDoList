package com.firebase.empleadocrud.modelo;

public class TaskVO {
    private int id_tbl_task;
    private String titulo;
    private String comentario;
    private String hora;
    private String fecha;
    private int fk_empleado;

 public TaskVO(){}

    public TaskVO(int id_tbl_task, String titulo, String comentario, String hora, String fecha, int fk_empleado) {
        this.id_tbl_task = id_tbl_task;
        this.titulo = titulo;
        this.comentario = comentario;
        this.hora = hora;
        this.fecha = fecha;
        this.fk_empleado = fk_empleado;
    }

    public int getId_tbl_task() {
        return id_tbl_task;
    }

    public void setId_tbl_task(int id_tbl_task) {
        this.id_tbl_task = id_tbl_task;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getComentario() {
        return comentario;
    }

    public void setComentario(String comentario) {
        this.comentario = comentario;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public int getFk_empleado() {
        return fk_empleado;
    }

    public void setFk_empleado(int fk_empleado) {
        this.fk_empleado = fk_empleado;
    }
}
