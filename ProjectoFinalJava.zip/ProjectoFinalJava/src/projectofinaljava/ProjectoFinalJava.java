/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectofinaljava;

import control.ControladorLogin;
import control.ControladorPrincipal;
import modelo.UsuariosDAO;
import modelo.UsuariosVO;
import vista.MenuAdmin;
import vista.MenuLogin;

/**
 *
 * @author kamiz
 */
public class ProjectoFinalJava {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        MenuLogin lg = new MenuLogin();
        MenuAdmin ma = new MenuAdmin();
        UsuariosVO v = new UsuariosVO();
        UsuariosDAO ud = new UsuariosDAO();
        
        ControladorLogin cl = new ControladorLogin(lg,ma,v,ud);
        ControladorPrincipal cp = new ControladorPrincipal(ma,v,ud);
        lg.setVisible(true);
    }
    
}
