/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import javax.swing.table.DefaultTableModel;
import modelo.UsuariosDAO;
import modelo.UsuariosVO;
import vista.MenuAdmin;

/**
 *
 * @author kamiz
 */
public class ControladorPrincipal implements ActionListener, WindowListener, MouseListener{
    
    MenuAdmin ma = new MenuAdmin();
    UsuariosVO v = new UsuariosVO();
    UsuariosDAO ud = new UsuariosDAO();
    
    int id= 0;
    public ControladorPrincipal(MenuAdmin ma, UsuariosVO v, UsuariosDAO ud){
        this.v = v;
        this.ma = ma;
        this.ud=ud;
        
        this.ma.jBtnBorrar.addActionListener(this);
        this.ma.jBtnGuardar.addActionListener(this);
        this.ma.jbtnNuevo.addActionListener(this);
        this.ma.jTable.addMouseListener(this);
        
        this.ma.addWindowListener(this);
    }
    
        private boolean checkEmpty(){
                
        
        if("".equals(v.getNombre())){
            ma.jOptionPaneAdmin.showMessageDialog(null, "No ha ingresado el nombre");
            return false;
        }
        if("".equals(v.getUsuario())){
            ma.jOptionPaneAdmin.showMessageDialog(null, "No ha ingresado el usuario");
            return false;
        }
        if("".equals(v.getContrasena())){
            ma.jOptionPaneAdmin.showMessageDialog(null, "No ha ingresado la contraseña");
            return false;
        }
        if(v.getContrasena().length()<8){
            ma.jOptionPaneAdmin.showMessageDialog(null, "La contraseña debe ser entre 8 a 20 caracteres");
            return false;
        }
        if(v.getContrasena().length()>20){
            ma.jOptionPaneAdmin.showMessageDialog(null, "La contraseña debe ser entre 8 a 20 caracteres");
            return false;
        }
        else{
            return true;
        }
    }
    
    private void cargarUsuario(){
        
    }
    
    private void agregarUsuario(){
        int estado;    
        v.setNombre(ma.jtxtNombre.getText());
        v.setUsuario(ma.jtxtUsername.getText());
        v.setContrasena(ma.jtxtPassword.getText());
        v.setEstado(ma.jComboEstado.getSelectedIndex()+1);
        estado = v.getEstado();
        
        if(this.checkEmpty()){
            if(ud.validarUsuario(v)==true){
                ma.jOptionPaneAdmin.showMessageDialog(null, "El usuario "+ v.getUsuario()+" ya existe");
            }else{
                ud.insertarUsuario(v);
                ma.jOptionPaneAdmin.showMessageDialog(null, "Se ha agregado el usuario"+ v.getUsuario());
            }
        }
        
        
    }
    
    private void mostrarDB(){
        DefaultTableModel m = new DefaultTableModel();
        m.setColumnCount(0);
        m.addColumn("ID empleado");
        m.addColumn("Nombre");
        m.addColumn("Usuario");
        m.addColumn("Contraseña");
        m.addColumn("Estado(1 activo, 2 inactivo)");
        
        for(UsuariosVO v : this.ud.consultarTabla()){
            m.addRow(new Object[]{v.getId(),v.getNombre(),
            v.getUsuario(),v.getContrasena(), v.getEstado()});
        }
        ma.jTable.setModel(m);
    }
    private void eliminarUsuario(){
        ud.eliminarUsuario(v); 
    }
    
    
    private void getFila(){
        int row= ma.jTable.getSelectedRow();
        String value = String.valueOf(ma.jTable.getValueAt(row, 0));
        String value1 = String.valueOf(ma.jTable.getValueAt(row, 1));
        String value2 = String.valueOf(ma.jTable.getValueAt(row, 2));
        String value3 = String.valueOf(ma.jTable.getValueAt(row, 3));
        String value4 = String.valueOf(ma.jTable.getValueAt(row, 4));
        
        id = Integer.parseInt(value);
        v.setId(id);
        int estado = Integer.parseInt(value4);
        ma.jtxtNombre.setText(value1);
        ma.jtxtUsername.setText(value2);
        ma.jtxtPassword.setText(value3);
        ma.jComboEstado.setSelectedIndex(estado-1);
        
    }
    
    private void actualizarUsuario(){
        v.setId(id);
        v.setNombre(ma.jtxtNombre.getText());
        v.setUsuario(ma.jtxtUsername.getText());
        v.setContrasena(ma.jtxtPassword.getText());
        v.setEstado(ma.jComboEstado.getSelectedIndex()+1);
        ud.modificar(v);
    }
    
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == ma.jBtnGuardar){
            this.actualizarUsuario();
            this.mostrarDB();
            ma.jOptionPaneAdmin.showMessageDialog(null, "Se ha actualizado el ID ="+v.getId());
        }if(e.getSource() == ma.jBtnBorrar){
            this.eliminarUsuario();
            this.mostrarDB();
            ma.jOptionPaneAdmin.showMessageDialog(null, "Se ha eliminado el usuario con ID = "+v.getId());
        }if(e.getSource()== ma.jbtnNuevo){
            this.agregarUsuario();
            this.mostrarDB();
        }
        
    }

    @Override
    public void windowOpened(WindowEvent e) {
        this.mostrarDB();
    }

    @Override
    public void windowClosing(WindowEvent e) {
        
    }

    @Override
    public void windowClosed(WindowEvent e) {
        
    }

    @Override
    public void windowIconified(WindowEvent e) {
    }

    @Override
    public void windowDeiconified(WindowEvent e) {
    }

    @Override
    public void windowActivated(WindowEvent e) {
    }

    @Override
    public void windowDeactivated(WindowEvent e) {
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        this.getFila();
    }

    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }
    
    
}
