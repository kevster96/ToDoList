/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import modelo.UsuariosDAO;
import modelo.UsuariosVO;
import vista.MenuAdmin;
import vista.MenuLogin;

/**
 *
 * @author kamiz
 */
public class ControladorLogin implements ActionListener{
    
    MenuLogin lg = new MenuLogin();
    MenuAdmin ma = new MenuAdmin();
    UsuariosVO v = new UsuariosVO();
    UsuariosDAO ud = new UsuariosDAO();
    
    public ControladorLogin(MenuLogin lg, MenuAdmin ma, UsuariosVO v, UsuariosDAO ud){
        
        this.lg = lg;
        this.ma = ma;
        this.v = v;
        this.ud = ud;
        
        this.lg.jBtnLogin.addActionListener(this);
    }
    
    private void validarAcceso(){
        int estado = 0;
        int id =0;
        
        this.v.setUsuario(this.lg.jTxtUsername.getText());
        this.v.setContrasena(this.lg.jPassword.getText());
        
        estado = this.ud.validarEstado(v);
        
        if(this.ud.validarExiste(v)==true){
            if(estado==1){
                lg.jOptionMessage.showMessageDialog(null, "Bienvenido");
                this.ma.setVisible(true);
            }else{
                lg.jOptionMessage.showMessageDialog(null, "Usuario o contraña invalida");
            }
        }
    }
    
    
    
    
    
    @Override
    public void actionPerformed(ActionEvent e) {
       if(e.getSource() == lg.jBtnLogin){
           this.validarAcceso();
       }
    }
    
    
    
}
