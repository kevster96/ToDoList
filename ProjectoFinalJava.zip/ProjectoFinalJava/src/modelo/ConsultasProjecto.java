/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.util.ArrayList;

/**
 *
 * @author kamiz
 */
public interface ConsultasProjecto {
    
    public ArrayList<UsuariosVO> consultarTabla();
    public boolean validarExiste(UsuariosVO v);
    public int validarEstado(UsuariosVO v);
    public boolean validarUsuario(UsuariosVO u);
    public void insertarUsuario(UsuariosVO v);
    public void modificar(UsuariosVO v);
    public void eliminarUsuario(UsuariosVO v);
}
