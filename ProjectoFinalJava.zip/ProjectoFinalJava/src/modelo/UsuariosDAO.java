/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import control.Conector;
import java.sql.ResultSet;
import java.util.ArrayList;

/**
 *
 * @author kamiz
 */
public class UsuariosDAO implements ConsultasProjecto {

    @Override
    public ArrayList<UsuariosVO> consultarTabla() {
        Conector c = new Conector();
        
        ArrayList<UsuariosVO> info = new ArrayList<>();
        
        try {
            c.conectar();
            ResultSet rs = c.consulta_obtener("SELECT * FROM tbl_empleado");
            
            while(rs.next()){
                UsuariosVO v = new UsuariosVO();
                v.setId(rs.getInt(1));
                v.setNombre(rs.getString(2));
                v.setUsuario(rs.getString(3));
                v.setContrasena(rs.getString(4));
                v.setEstado(rs.getInt(5));
                
                info.add(v);
            }
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
        return info;
    }
    
        @Override
    public boolean validarUsuario(UsuariosVO u) {
        Conector c = new Conector();
        boolean existe = false;
        String user ;
        try{
            ResultSet rs = c.consulta_obtener("SELECT usuario from tbl_empleado WHERE usuario ='"+u.getUsuario()+"';");
            
            while(rs.next()){
                u.setUsuario(rs.getString(1));
                if("".equals(u.getUsuario())){
                    existe = false;
                }else{
                    existe = true;
                }
                
            }
            user = u.getUsuario();
        }catch(Exception e){
            System.err.println(e);
        }
        return existe;
    }

    @Override
    public boolean validarExiste(UsuariosVO v) {
       Conector c = new Conector();
       
       boolean exist= false;
       
       try{
           c.conectar();
           ResultSet rs = c.consulta_obtener("SELECT * FROM tbl_empleado "
                   + "WHERE usuario='"+v.getUsuario()+"' and contrasena='"+v.getContrasena()+"';");
           
           if(rs.next()){
               exist = true;
               return exist;
           }else{
               return exist=false;
           }
       }catch(Exception e){
           System.err.println(e.getMessage());
       }
       return exist;
    }

    @Override
    public int validarEstado(UsuariosVO v) {
       int activo = 2;
       Conector c = new Conector();
       UsuariosVO uv = new UsuariosVO();
       
       try{
           c.conectar();
           
           ResultSet rs = c.consulta_obtener("SELECT fk_estado from tbl_empleado WHERE usuario='"+v.getUsuario()+"' and contrasena='"+v.getContrasena()+"';");
           while(rs.next()){
               uv.setEstado(rs.getInt(1));
               
           }
           activo= uv.getEstado();
           if(activo==1){
               return activo;
           }else{
               
           }
       }catch(Exception e){
           System.err.println(e.getMessage());
       }
       return activo;
    }

    @Override
    public void insertarUsuario(UsuariosVO v) {
        Conector c = new Conector();
        
        try {
            c.conectar();
            c.consulta_multi("INSERT INTO tbl_empleado(nombrecompleto,usuario,contrasena,fk_estado) "
                    + "VALUES('"+v.getNombre()+"', '"+v.getUsuario()+"', '"+v.getContrasena()+"', "+v.getEstado()+");");
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
        c.desconectar();
    }

    @Override
    public void modificar(UsuariosVO v) {
        Conector c = new Conector();
        
        try {
             c.conectar();
             
             c.consulta_multi("UPDATE tbl_empleado SET nombrecompleto='"+v.getNombre()+"', usuario='"+v.getUsuario()+"', "
             + "contrasena='"+v.getContrasena()+"', fk_estado ="+v.getEstado()+" WHERE id_tblempleado="+v.getId()+";");
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
        c.desconectar();
    }

    @Override
    public void eliminarUsuario(UsuariosVO v) {
        Conector c = new Conector();
        
        try {
            c.conectar();
            c.consulta_multi("DELETE FROM tbl_empleado WHERE id_tblempleado="+v.getId());
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
        c.desconectar();
    }


    
    
    
}
